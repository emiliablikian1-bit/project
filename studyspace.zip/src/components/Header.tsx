import { motion } from 'motion/react';
import { Search } from 'lucide-react';

interface HeaderProps {
  activePage: string;
  onNavigate: (page: string) => void;
}

export default function Header({ activePage, onNavigate }: HeaderProps) {
  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'courses', label: 'Courses' },
    { id: 'blog', label: 'Blog' },
    { id: 'opportunities', label: 'Opportunities' },
  ];

  return (
    <header className="fixed top-0 left-0 right-0 z-50 glass-nav">
      <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <button 
            onClick={() => onNavigate('home')}
            className="text-xl font-extrabold tracking-tighter text-accent-blue"
          >
            StudySpace
          </button>
          <nav className="hidden md:flex items-center gap-6">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                className={`relative py-1 text-sm font-medium transition-colors ${
                  activePage === item.id ? 'text-accent-blue' : 'text-on-surface-variant hover:text-accent-blue'
                }`}
              >
                {item.label}
                {activePage === item.id && (
                  <motion.div
                    layoutId="nav-underline"
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-accent-blue"
                  />
                )}
              </button>
            ))}
          </nav>
        </div>
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center bg-surface-container-low px-3 py-1.5 rounded-full border border-surface-container">
            <Search className="w-4 h-4 text-on-surface-variant mr-2" />
            <input 
              type="text" 
              placeholder="Search..." 
              className="bg-transparent border-none text-sm outline-none placeholder:text-on-surface-variant/50 w-32 focus:w-48 transition-all"
            />
          </div>
          <button 
            onClick={() => onNavigate('dashboard')}
            className={`button-secondary text-sm ${activePage === 'dashboard' ? 'ring-2 ring-accent-blue ring-offset-2' : ''}`}
          >
            Sign In
          </button>
        </div>
      </div>
    </header>
  );
}
