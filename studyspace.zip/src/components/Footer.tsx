export default function Footer() {
  return (
    <footer className="bg-surface-container-lowest border-t border-surface-container py-12 px-6">
      <div className="max-w-7xl mx-auto flex flex-col md:flex-row justify-between items-center gap-6">
        <div>
          <div className="text-lg font-bold text-on-surface mb-2">StudySpace</div>
          <p className="text-xs text-on-surface-variant">
            © 2024 StudySpace. Empowering student growth through minimalist learning.
          </p>
        </div>
        <div className="flex flex-wrap justify-center gap-8 text-xs text-on-surface-variant font-medium">
          <a href="#" className="hover:text-accent-blue transition-colors">Contact</a>
          <a href="#" className="hover:text-accent-blue transition-colors">Privacy Policy</a>
          <a href="#" className="hover:text-accent-blue transition-colors">Terms of Service</a>
          <a href="#" className="hover:text-accent-blue transition-colors">FAQ</a>
        </div>
      </div>
    </footer>
  );
}
