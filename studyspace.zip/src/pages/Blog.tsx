import { motion } from 'motion/react';
import { ArrowRight, ChevronLeft, ChevronRight, Mail } from 'lucide-react';

export default function Blog() {
  const articles = [
    {
      id: 1,
      category: 'Career Advice',
      date: 'Oct 20, 2024',
      title: 'The Modern Portfolio: How to Stand Out in Tech',
      desc: 'Building a digital presence that showcases your skills beyond the simple resume format for modern employers.',
      image: 'https://images.unsplash.com/photo-1499750310107-5fef28a66643?q=80&w=2070&auto=format&fit=crop'
    },
    {
      id: 2,
      category: 'Study Tips',
      date: 'Oct 18, 2024',
      title: 'Active Recall vs. Passive Reading: What Wins?',
      desc: 'Comparing common study methods and why testing yourself is the fastest way to long-term memory mastery.',
      image: 'https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?q=80&w=2069&auto=format&fit=crop'
    },
    {
      id: 3,
      category: 'Resources',
      date: 'Oct 15, 2024',
      title: '5 Essential Tools for Research-Heavy Degrees',
      desc: 'A curated list of software and methods to organize citations, manage PDFs, and streamline your thesis writing.',
      image: 'https://images.unsplash.com/photo-1456513080510-7bf3a84b82f8?q=80&w=2073&auto=format&fit=crop'
    }
  ];

  return (
    <div className="pt-24 pb-20 px-6 max-w-7xl mx-auto">
      <header className="mb-12 border-b border-surface-container pb-8">
        <h1 className="text-4xl font-bold mb-2">Our Blog</h1>
        <p className="text-lg text-on-surface-variant max-w-2xl">Insights, study techniques, and career advice to help you navigate your academic journey with clarity.</p>
      </header>

      {/* Featured Article */}
      <section className="mb-20">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
          <div className="lg:col-span-7 overflow-hidden rounded-3xl shadow-xl shadow-black/5 group">
            <img 
              src="https://images.unsplash.com/photo-1517245386807-bb43f82c33c4?q=80&w=2070&auto=format&fit=crop" 
              alt="Featured" 
              className="w-full h-[400px] object-cover group-hover:scale-105 transition-transform duration-700" 
              referrerPolicy="no-referrer" 
            />
          </div>
          <div className="lg:col-span-5 space-y-4">
            <div className="flex items-center gap-3">
              <span className="bg-primary-container text-accent-blue px-3 py-1 rounded-full text-xs font-bold">Study Tips</span>
              <span className="text-xs text-on-surface-variant font-bold">Oct 24, 2024</span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold leading-tight">Mastering Deep Focus: The Science of Uninterrupted Study Sessions</h2>
            <p className="text-on-surface-variant leading-relaxed">Discover how to architect your environment and schedule to enter flow states effortlessly, reducing study time while increasing retention and comprehension.</p>
            <button className="flex items-center gap-2 text-accent-blue font-bold px-0 py-2 group">
              Read Full Article <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      {/* Latest Articles */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10 border-b border-surface-container pb-6">
        <h3 className="text-2xl font-bold">Latest Articles</h3>
        <div className="flex flex-wrap gap-2">
          {['All Posts', 'Career Advice', 'Productivity', 'Resources'].map((filter, i) => (
            <button 
              key={filter}
              className={`px-4 py-2 rounded-full text-xs font-bold transition-all ${i === 0 ? 'bg-primary-container text-accent-blue' : 'bg-surface-container-low text-on-surface-variant hover:bg-surface-container'}`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {articles.map(post => (
          <article key={post.id} className="group flex flex-col">
            <div className="overflow-hidden rounded-2xl mb-6 border border-surface-container">
              <img src={post.image} alt={post.title} className="w-full aspect-video object-cover group-hover:scale-105 transition-transform duration-500" referrerPolicy="no-referrer" />
            </div>
            <div className="flex items-center gap-3 mb-3">
              <span className="text-accent-blue font-bold text-xs uppercase tracking-wider">{post.category}</span>
              <span className="text-on-surface-variant opacity-30">•</span>
              <span className="text-on-surface-variant font-bold text-xs">{post.date}</span>
            </div>
            <h4 className="text-xl font-bold mb-3 group-hover:text-accent-blue transition-colors">{post.title}</h4>
            <p className="text-sm text-on-surface-variant mb-4 line-clamp-2">{post.desc}</p>
            <button className="mt-auto flex items-center gap-1 text-accent-blue font-bold text-xs">
              Read More <ChevronRight className="w-4 h-4" />
            </button>
          </article>
        ))}

        {/* Newsletter Bento Block */}
        <div className="bg-primary-container/40 rounded-2xl p-8 border border-primary-container flex flex-col justify-center items-center text-center">
          <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center text-accent-blue mb-4 shadow-lg shadow-blue-900/5">
            <Mail className="w-6 h-6" />
          </div>
          <h4 className="text-xl font-bold mb-2">Weekly Insights</h4>
          <p className="text-sm text-on-surface-variant mb-6">Get the latest study tips and career advice delivered to your inbox every Sunday.</p>
          <div className="w-full space-y-3">
            <input 
              type="email" 
              placeholder="Email address" 
              className="w-full bg-white border-none rounded-xl px-4 py-3 text-sm focus:ring-2 focus:ring-accent-blue shadow-sm"
            />
            <button className="w-full button-primary shadow-lg shadow-primary/10">Subscribe Now</button>
          </div>
        </div>
      </section>

      {/* Pagination */}
      <div className="mt-20 flex justify-center items-center gap-3">
        <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface-variant hover:bg-surface-container transition-colors">
          <ChevronLeft className="w-4 h-4" />
        </button>
        <button className="w-10 h-10 flex items-center justify-center rounded-xl bg-primary text-on-primary font-bold">1</button>
        <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">2</button>
        <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">3</button>
        <span className="text-on-surface-variant px-2 italic opacity-50">...</span>
        <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">12</button>
        <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface-variant hover:bg-surface-container transition-colors">
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
