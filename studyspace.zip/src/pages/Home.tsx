import { motion } from 'motion/react';
import { GraduationCap, Clock, Users, Rocket } from 'lucide-react';

interface HomeProps {
  onNavigate: (page: string) => void;
}

export default function Home({ onNavigate }: HomeProps) {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="px-6 py-16 md:py-32 overflow-hidden">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6 }}
            className="z-10"
          >
            <span className="inline-block px-4 py-1.5 mb-6 text-primary bg-primary-container rounded-full text-sm font-medium">
              Empowering Student Growth
            </span>
            <h1 className="text-4xl md:text-6xl font-bold text-on-surface mb-6 leading-[1.1]">
              Unlock Your Potential
            </h1>
            <p className="text-lg text-on-surface-variant mb-10 max-w-lg leading-relaxed">
              StudySpace provides a minimalist, focus-oriented environment for modern learners. Access high-quality resources and expert guidance tailored to your academic journey.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <button 
                onClick={() => onNavigate('dashboard')}
                className="button-primary px-10 py-4 shadow-lg shadow-primary/20"
              >
                Get Started
              </button>
              <button 
                onClick={() => onNavigate('courses')}
                className="border border-surface-container-highest text-primary px-10 py-4 rounded-lg font-semibold hover:bg-surface-container transition-all"
              >
                Explore Courses
              </button>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="relative"
          >
            <div className="absolute inset-0 bg-primary-container/30 blur-[100px] rounded-full -z-10"></div>
            <img 
              src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2071&auto=format&fit=crop" 
              alt="Students studying together"
              className="rounded-2xl shadow-2xl w-full h-[500px] object-cover"
              referrerPolicy="no-referrer"
            />
          </motion.div>
        </div>
      </section>

      {/* Why StudySpace Bento Grid */}
      <section className="bg-surface-container-low py-24 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Why StudySpace?</h2>
            <p className="text-on-surface-variant max-w-2xl mx-auto">Designed to eliminate visual noise and prioritize your educational focus.</p>
          </div>
          
          <motion.div 
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            <motion.div variants={itemVariants} className="md:col-span-2 bg-white border border-surface-container p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow group flex flex-col justify-between gap-8">
              <div>
                <div className="w-12 h-12 bg-primary-container text-accent-blue rounded-xl flex items-center justify-center mb-6">
                  <GraduationCap className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Expert Mentors</h3>
                <p className="text-on-surface-variant">Connect with industry professionals and top-tier educators who provide personalized guidance and feedback on your specific learning path.</p>
              </div>
              <img 
                src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070&auto=format&fit=crop" 
                alt="Expert Mentorship"
                className="rounded-xl h-48 w-full object-cover grayscale-[20%] group-hover:grayscale-0 transition-all"
                referrerPolicy="no-referrer"
              />
            </motion.div>

            <motion.div variants={itemVariants} className="bg-white border border-surface-container p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-primary-container text-accent-blue rounded-xl flex items-center justify-center mb-6">
                <Clock className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Flexible Schedule</h3>
              <p className="text-on-surface-variant">Learn at your own pace with 24/7 access to all platform materials. Our system adapts to your busy life, not the other way around.</p>
            </motion.div>

            <motion.div variants={itemVariants} className="bg-white border border-surface-container p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow">
              <div className="w-12 h-12 bg-primary-container text-accent-blue rounded-xl flex items-center justify-center mb-6">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-2xl font-bold mb-4">Community Support</h3>
              <p className="text-on-surface-variant">Join a global network of ambitious students. Share resources, ask questions, and collaborate on projects in a focused environment.</p>
            </motion.div>

            <motion.div variants={itemVariants} className="md:col-span-2 bg-white border border-surface-container p-8 rounded-2xl shadow-sm hover:shadow-md transition-shadow flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <div className="w-12 h-12 bg-primary-container text-accent-blue rounded-xl flex items-center justify-center mb-6">
                  <Rocket className="w-6 h-6" />
                </div>
                <h3 className="text-2xl font-bold mb-4">Accelerate Your Career</h3>
                <p className="text-on-surface-variant">Our curriculum is designed to bridge the gap between academic theory and practical, real-world application.</p>
              </div>
              <div className="flex-1 w-full bg-surface-container h-32 rounded-xl flex items-center justify-center p-6 border-dashed border-2 border-surface-dim">
                <span className="font-bold text-accent-blue opacity-40">Interactive Career Roadmap</span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 px-6">
        <div className="max-w-7xl mx-auto bg-primary text-on-primary rounded-3xl p-12 md:p-24 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
          <div className="absolute bottom-0 left-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -ml-32 -mb-32"></div>
          <div className="relative z-10 max-w-3xl mx-auto">
            <h2 className="text-3xl md:text-5xl font-bold mb-6">Ready to start your journey?</h2>
            <p className="text-lg opacity-90 mb-12">
              Join over 50,000 students who are already mastering new skills and advancing their education with StudySpace.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-6">
              <button 
                onClick={() => onNavigate('dashboard')}
                className="bg-white text-primary px-10 py-5 rounded-xl font-bold hover:shadow-xl transition-all"
              >
                Create Free Account
              </button>
              <button 
                onClick={() => onNavigate('courses')}
                className="border border-white/30 text-white px-10 py-5 rounded-xl font-bold hover:bg-white/10 transition-all"
              >
                View All Courses
              </button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
