import { useState } from 'react';
import { motion } from 'motion/react';
import { Star, ChevronLeft, ChevronRight } from 'lucide-react';

export default function Courses() {
  const [activeCategory, setActiveCategory] = useState<string[]>(['Development']);
  const [activeLevel, setActiveLevel] = useState<string>('all');

  const categories = ['Design', 'Development', 'Business', 'Finance', 'Marketing'];
  const levels = ['Beginner', 'Intermediate', 'Advanced'];

  const courseData = [
    {
      id: 1,
      title: 'Advanced React Patterns',
      instructor: 'Dr. Sarah Jenkins',
      category: 'Development',
      rating: 4.9,
      reviews: '1,240',
      image: 'https://images.unsplash.com/photo-1633356122544-f134324a6cee?q=80&w=2070&auto=format&fit=crop',
    },
    {
      id: 2,
      title: 'Human-Centered UI Design',
      instructor: 'Marcus Thorne',
      category: 'Design',
      rating: 4.7,
      reviews: '892',
      image: 'https://images.unsplash.com/photo-1541462608141-ad4d157ee785?q=80&w=2070&auto=format&fit=crop',
    },
    {
      id: 3,
      title: 'Data-Driven Strategy',
      instructor: 'Elena Rodriguez',
      category: 'Business',
      rating: 4.8,
      reviews: '560',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?q=80&w=2015&auto=format&fit=crop',
    },
    {
      id: 4,
      title: 'Python Foundation for AI',
      instructor: 'Dr. Kevin Park',
      category: 'Development',
      rating: 4.9,
      reviews: '2,105',
      image: 'https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?q=80&w=2070&auto=format&fit=crop',
    },
    {
      id: 5,
      title: 'Visual Identity Masterclass',
      instructor: 'Sophia Valli',
      category: 'Design',
      rating: 4.6,
      reviews: '312',
      image: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?q=80&w=2070&auto=format&fit=crop',
    },
    {
      id: 6,
      title: 'Entrepreneurial Mindset',
      instructor: 'David G. Thompson',
      category: 'Business',
      rating: 5.0,
      reviews: '218',
      image: 'https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2070&auto=format&fit=crop',
    }
  ];

  const filteredCourses = courseData.filter(course => 
    activeCategory.includes(course.category)
  );

  const toggleCategory = (cat: string) => {
    setActiveCategory(prev => 
      prev.includes(cat) ? prev.filter(c => c !== cat) : [...prev, cat]
    );
  };

  return (
    <div className="pt-24 pb-20 px-6 max-w-7xl mx-auto">
      <header className="mb-12">
        <h1 className="text-4xl font-bold mb-4">Explore our courses</h1>
        <p className="text-on-surface-variant max-w-2xl">Elevate your skills with professional-grade learning materials curated by the industry's finest mentors.</p>
      </header>

      <div className="flex flex-col lg:flex-row gap-12">
        {/* Sidebar */}
        <aside className="w-full lg:w-64 flex-shrink-0">
          <div className="space-y-8 sticky top-28">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant mb-4">Category</h3>
              <div className="space-y-3">
                {categories.map(cat => (
                  <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                    <input 
                      type="checkbox" 
                      checked={activeCategory.includes(cat)}
                      onChange={() => toggleCategory(cat)}
                      className="rounded border-surface-container text-accent-blue focus:ring-primary-container"
                    />
                    <span className={`text-sm transition-colors ${activeCategory.includes(cat) ? 'text-on-surface font-semibold' : 'text-on-surface-variant hover:text-on-surface'}`}>
                      {cat}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <h3 className="text-xs font-bold uppercase tracking-widest text-on-surface-variant mb-4">Level</h3>
              <div className="space-y-3">
                {levels.map(level => (
                  <label key={level} className="flex items-center gap-3 cursor-pointer group">
                    <input 
                      type="radio" 
                      name="level"
                      checked={activeLevel === level}
                      onChange={() => setActiveLevel(level)}
                      className="border-surface-container text-accent-blue focus:ring-primary-container"
                    />
                    <span className={`text-sm transition-colors ${activeLevel === level ? 'text-on-surface font-semibold' : 'text-on-surface-variant hover:text-on-surface'}`}>
                      {level}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <button 
              onClick={() => {setActiveCategory([]); setActiveLevel('all');}}
              className="w-full py-3 bg-surface-container-high text-on-surface font-medium rounded-xl hover:bg-surface-container-highest transition-colors"
            >
              Reset Filters
            </button>
          </div>
        </aside>

        {/* Main Content */}
        <section className="flex-grow">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-8">
            {filteredCourses.map(course => (
              <motion.div 
                key={course.id}
                layout
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="bg-white border border-surface-container rounded-2xl overflow-hidden card-hover group"
              >
                <div className="h-48 overflow-hidden relative">
                  <img 
                    src={course.image} 
                    alt={course.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute top-4 left-4 bg-primary-container/90 backdrop-blur px-3 py-1 rounded-lg">
                    <span className="text-accent-blue text-xs font-bold">{course.category}</span>
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2 line-clamp-1">{course.title}</h3>
                  <p className="text-sm text-on-surface-variant mb-4">{course.instructor}</p>
                  <div className="flex items-center gap-2 mb-6">
                    <Star className="w-4 h-4 text-amber-400 fill-amber-400" />
                    <span className="text-sm font-bold">{course.rating}</span>
                    <span className="text-xs text-on-surface-variant">({course.reviews} reviews)</span>
                  </div>
                  <button className="w-full py-3 button-secondary text-sm">View Details</button>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Pagination */}
          <div className="mt-16 flex justify-center items-center gap-3">
            <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface-variant hover:bg-surface-container transition-colors">
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button className="w-10 h-10 flex items-center justify-center rounded-xl bg-primary-container text-accent-blue font-bold">1</button>
            <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">2</button>
            <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">3</button>
            <span className="w-10 h-10 flex items-center justify-center text-on-surface-variant">...</span>
            <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface hover:bg-surface-container transition-colors">12</button>
            <button className="w-10 h-10 flex items-center justify-center rounded-xl border border-surface-container text-on-surface-variant hover:bg-surface-container transition-colors">
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </section>
      </div>
    </div>
  );
}
