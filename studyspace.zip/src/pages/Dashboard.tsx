import { motion } from 'motion/react';
import { PlayCircle, Notebook, MessageSquare, Download, Award, Flame, Check } from 'lucide-react';

export default function Dashboard() {
  return (
    <div className="pt-24 pb-20 px-6 max-w-7xl mx-auto">
      {/* Welcome Section */}
      <section className="mb-12">
        <div className="bg-white border border-surface-container p-8 rounded-2xl shadow-sm flex flex-col md:flex-row justify-between items-center gap-8">
          <div className="flex-1">
            <h1 className="text-4xl font-bold mb-2">Welcome back, Alex!</h1>
            <p className="text-lg text-on-surface-variant">You've completed 65% of your weekly goals. Stay focused, you're almost there!</p>
            <div className="mt-6 flex items-center gap-4">
              <div className="flex -space-x-3">
                <img className="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://i.pravatar.cc/100?u=1" alt="friend" referrerPolicy="no-referrer" />
                <img className="w-10 h-10 rounded-full border-2 border-white object-cover" src="https://i.pravatar.cc/100?u=2" alt="friend" referrerPolicy="no-referrer" />
                <div className="w-10 h-10 rounded-full border-2 border-white bg-secondary-container flex items-center justify-center text-xs font-bold text-on-secondary-container">+12</div>
              </div>
              <span className="text-xs text-on-surface-variant font-medium">Friends studying now</span>
            </div>
          </div>
          <div className="w-full md:w-64 flex flex-col items-center">
            <div className="relative w-32 h-32 mb-4">
              <svg className="w-full h-full transform -rotate-90">
                <circle className="text-surface-container" cx="64" cy="64" fill="transparent" r="56" stroke="currentColor" strokeWidth="12" />
                <circle className="text-accent-blue" cx="64" cy="64" fill="transparent" r="56" stroke="currentColor" strokeDasharray="351.85" strokeDashoffset="123.15" strokeWidth="12" strokeLinecap="round" />
              </svg>
              <div className="absolute inset-0 flex items-center justify-center">
                <span className="text-3xl font-bold">65%</span>
              </div>
            </div>
            <span className="text-sm font-bold">Overall Progress</span>
          </div>
        </div>
      </section>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
          {/* My Courses */}
          <section>
            <div className="flex justify-between items-end mb-6">
              <div>
                <h2 className="text-2xl font-bold">My Courses</h2>
                <p className="text-sm text-on-surface-variant">Continue where you left off</p>
              </div>
              <button className="text-accent-blue font-bold text-sm hover:underline">View All</button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white border border-surface-container p-6 rounded-2xl card-hover group">
                <div className="mb-4 overflow-hidden rounded-xl h-32">
                  <img src="https://images.unsplash.com/photo-1541462608141-ad4d157ee785?q=80&w=2070&auto=format&fit=crop" className="w-full h-full object-cover" alt="course" referrerPolicy="no-referrer" />
                </div>
                <h3 className="text-lg font-bold mb-1">Introduction to UI Design</h3>
                <p className="text-xs text-on-surface-variant mb-4">Module 4: Visual Hierarchy</p>
                <div className="w-full bg-surface-container rounded-full h-2.5 mb-2">
                  <div className="bg-accent-blue h-2.5 rounded-full" style={{ width: '78%' }}></div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-on-surface-variant">78% Complete</span>
                  <PlayCircle className="w-6 h-6 text-accent-blue cursor-pointer" />
                </div>
              </div>
              <div className="bg-white border border-surface-container p-6 rounded-2xl card-hover group">
                <div className="mb-4 overflow-hidden rounded-xl h-32">
                  <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2070&auto=format&fit=crop" className="w-full h-full object-cover" alt="course" referrerPolicy="no-referrer" />
                </div>
                <h3 className="text-lg font-bold mb-1">Advanced JavaScript</h3>
                <p className="text-xs text-on-surface-variant mb-4">Module 2: Async Patterns</p>
                <div className="w-full bg-surface-container rounded-full h-2.5 mb-2">
                  <div className="bg-accent-blue h-2.5 rounded-full" style={{ width: '42%' }}></div>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-on-surface-variant">42% Complete</span>
                  <PlayCircle className="w-6 h-6 text-accent-blue cursor-pointer" />
                </div>
              </div>
            </div>
          </section>

          {/* Recommended Area */}
          <section>
            <h2 className="text-2xl font-bold mb-6">Recommended for You</h2>
            <div className="bg-tertiary-container/30 p-8 rounded-3xl border border-tertiary-container flex flex-col md:flex-row items-center gap-8">
              <div className="flex-1">
                <span className="bg-white text-on-surface px-3 py-1 rounded-full text-xs font-bold mb-4 inline-block">New Workshop</span>
                <h3 className="text-2xl font-bold mb-3">Mastering Minimalist Motion</h3>
                <p className="text-on-surface-variant mb-6 text-sm">Learn how to add subtle animations to your UI without increasing cognitive load. Taught by industry leaders.</p>
                <button className="button-primary shadow-lg shadow-primary/20">Enroll Now</button>
              </div>
              <div className="w-full md:w-1/3">
                <img className="rounded-2xl shadow-xl w-full h-48 object-cover" src="https://images.unsplash.com/photo-1517048676732-d65bc937f952?q=80&w=2070&auto=format&fit=crop" alt="workshop" referrerPolicy="no-referrer" />
              </div>
            </div>
          </section>
        </div>

        <aside className="space-y-8">
          {/* Upcoming */}
          <div className="bg-white border border-surface-container p-6 rounded-2xl shadow-sm">
            <h3 className="text-xl font-bold mb-6">Upcoming</h3>
            <div className="space-y-6">
              {[
                { day: '12', mo: 'Oct', title: 'Design Systems Essay', meta: 'Due in 2 days', color: 'bg-red-50 text-red-600' },
                { day: '15', mo: 'Oct', title: 'Live Q&A: React Hooks', meta: 'Starts at 4:00 PM', color: 'bg-primary-container text-accent-blue' },
                { day: '18', mo: 'Oct', title: 'Typography Quiz', meta: 'Next week', color: 'bg-surface-container-high text-on-surface-variant', opacity: true }
              ].map((item, i) => (
                <div key={i} className={`flex gap-4 ${item.opacity ? 'opacity-60' : ''}`}>
                  <div className={`flex-shrink-0 w-12 h-12 rounded-xl flex flex-col items-center justify-center ${item.color}`}>
                    <span className="text-xs font-bold">{item.day}</span>
                    <span className="text-[10px] uppercase font-bold">{item.mo}</span>
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-on-surface">{item.title}</h4>
                    <p className="text-xs text-on-surface-variant">{item.meta}</p>
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-8 py-3 rounded-xl border border-surface-container text-sm font-bold hover:bg-surface-container transition-colors">View Schedule</button>
          </div>

          {/* Quick Actions */}
          <div className="bg-white border border-surface-container p-6 rounded-2xl shadow-sm">
            <h3 className="text-xl font-bold mb-6">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-4">
              {[
                { icon: Notebook, label: 'New Note' },
                { icon: MessageSquare, label: 'Ask AI' },
                { icon: Download, label: 'Library' },
                { icon: Award, label: 'Certificates' }
              ].map((item, i) => (
                <button key={i} className="flex flex-col items-center justify-center p-4 rounded-xl bg-surface-container-low hover:bg-primary-container hover:text-accent-blue transition-all group">
                  <item.icon className="w-5 h-5 mb-2 group-hover:scale-110 transition-transform" />
                  <span className="text-xs font-bold text-center">{item.label}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Streak */}
          <div className="bg-gradient-to-br from-accent-blue to-blue-700 p-6 rounded-2xl text-white shadow-xl shadow-accent-blue/20">
            <div className="flex items-center gap-3 mb-4">
              <Flame className="w-6 h-6 text-yellow-300 fill-yellow-300" />
              <h3 className="text-xl font-bold">12 Day Streak!</h3>
            </div>
            <p className="text-xs text-blue-50 opacity-90 mb-6 font-medium">You're in the top 5% of active learners this month. Keep the momentum going!</p>
            <div className="flex justify-between">
              {['M', 'T', 'W', 'T', 'F'].map((day, i) => (
                <div key={i} className="flex flex-col items-center">
                  <span className="text-[10px] uppercase opacity-70 mb-2 font-bold">{day}</span>
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center border ${i < 3 ? 'bg-white text-accent-blue border-white' : 'border-white/30'}`}>
                    {i < 3 && <Check className="w-3 h-3 stroke-[4]" />}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
