import { motion } from 'motion/react';
import { Filter, SortAsc, Calendar, DollarSign, ExternalLink, Rocket } from 'lucide-react';

export default function Opportunities() {
  const opportunities = [
    {
      id: 1,
      type: 'Internship',
      title: 'Product Design Summer \'25',
      partner: 'Global Tech Solutions • Remote',
      desc: 'Gain hands-on experience in UI/UX research and prototyping with our award-winning design team in a fast-paced environment.',
      meta: 'Ends in 12 days',
      icon: 'https://images.unsplash.com/photo-1560179707-f14e90ef3623?q=80&w=2073&auto=format&fit=crop',
      color: 'bg-tertiary-container text-on-tertiary-container'
    },
    {
      id: 2,
      type: 'Scholarship',
      title: 'Academic Excellence Grant',
      partner: 'Future Leaders Foundation',
      desc: 'A full-tuition scholarship awarded to undergraduate students demonstrating exceptional potential in STEM fields and leadership.',
      meta: '$25,000 / Year',
      icon: 'https://images.unsplash.com/photo-1523240795612-9a054b0db644?q=80&w=2070&auto=format&fit=crop',
      color: 'bg-secondary-container text-on-secondary-container'
    },
    {
      id: 3,
      type: 'Workshop',
      title: 'AI & Ethics Intensive',
      partner: 'StudySpace Academy • Hybrid',
      desc: 'A 3-day intensive workshop exploring the sociological and technical implications of large language models in modern education.',
      meta: 'Oct 14 - 16',
      icon: 'https://images.unsplash.com/photo-1591115765373-520b7a42951e?q=80&w=2070&auto=format&fit=crop',
      color: 'bg-primary-container text-accent-blue'
    }
  ];

  return (
    <div className="pt-24 pb-20 px-6 max-w-7xl mx-auto">
      <header className="mb-16">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <h1 className="text-4xl font-bold mb-4">Discover Your Future</h1>
            <p className="text-lg text-on-surface-variant max-w-2xl">
              Hand-curated internships, scholarships, and workshops to help you grow. Your journey from student to professional starts with the right opportunity.
            </p>
          </div>
          <div className="flex gap-2">
            <button className="bg-primary-container text-accent-blue px-4 py-2 rounded-lg font-bold flex items-center gap-2 text-sm">
              <Filter className="w-4 h-4" /> Filter
            </button>
            <button className="bg-white border border-surface-container text-on-surface px-4 py-2 rounded-lg font-bold flex items-center gap-2 text-sm">
              <SortAsc className="w-4 h-4" /> Sort
            </button>
          </div>
        </div>
      </header>

      <div className="flex flex-wrap gap-3 mb-12">
        {['All Paths', 'Internships', 'Scholarships', 'Workshops', 'Grants'].map((tag, i) => (
          <span 
            key={tag} 
            className={`px-4 py-1.5 rounded-full text-sm font-bold cursor-pointer transition-all ${i === 0 ? 'bg-primary-container text-accent-blue' : 'bg-white border border-surface-container text-on-surface-variant hover:bg-surface-container'}`}
          >
            {tag}
          </span>
        ))}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {opportunities.map(opp => (
          <motion.div 
            key={opp.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white border border-surface-container rounded-2xl p-6 flex flex-col card-hover"
          >
            <div className="flex justify-between items-start mb-6">
              <div className="w-12 h-12 rounded-xl bg-surface-container overflow-hidden">
                <img src={opp.icon} alt="logo" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <span className={`${opp.color} px-3 py-1 rounded-full text-[10px] font-bold uppercase tracking-wider`}>
                {opp.type}
              </span>
            </div>
            <h3 className="text-xl font-bold mb-1 hover:text-accent-blue transition-colors cursor-pointer">{opp.title}</h3>
            <p className="text-sm font-medium text-on-surface-variant mb-4">{opp.partner}</p>
            <p className="text-sm text-on-surface-variant/80 line-clamp-2 mb-6">{opp.desc}</p>
            <div className="mt-auto flex items-center justify-between">
              <span className="text-xs text-on-surface-variant flex items-center gap-1 font-medium">
                {opp.type === 'Scholarship' ? <DollarSign className="w-3.5 h-3.5" /> : <Calendar className="w-3.5 h-3.5" />}
                {opp.meta}
              </span>
              <button className="button-secondary text-xs font-bold py-2 px-4 group flex items-center gap-2">
                Apply Now <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
              </button>
            </div>
          </motion.div>
        ))}

        {/* Featured Card */}
        <div className="bg-primary-container border border-blue-100 rounded-3xl p-8 md:col-span-2 flex flex-col md:flex-row gap-10 items-center card-hover">
          <div className="flex-shrink-0 w-32 h-32 rounded-3xl bg-white flex items-center justify-center p-6 shadow-xl shadow-blue-900/5">
            <Rocket className="w-full h-full text-accent-blue" />
          </div>
          <div className="flex-grow">
            <div className="flex items-center gap-3 mb-2">
              <span className="bg-accent-blue text-white px-3 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-widest">Featured</span>
              <span className="text-accent-blue font-bold text-xs">StudySpace Fellowship '24</span>
            </div>
            <h3 className="text-3xl font-bold text-blue-900 mb-4">Research Ambassador Program</h3>
            <p className="text-blue-800/80 mb-6 max-w-xl leading-relaxed text-sm">Join our elite group of student researchers. Get exclusive access to beta features, a monthly stipend, and direct mentorship from our engineering leads.</p>
            <button className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-all shadow-lg shadow-blue-600/20 active:scale-95 text-sm">
              Explore Fellowship
            </button>
          </div>
        </div>
      </div>

      <div className="mt-20 flex flex-col items-center gap-4">
        <p className="text-sm text-on-surface-variant font-medium">Showing 5 of 42 opportunities</p>
        <button className="text-accent-blue font-bold text-sm border-b-2 border-accent-blue/30 hover:border-accent-blue pb-1 transition-all">
          Load more opportunities
        </button>
      </div>
    </div>
  );
}
